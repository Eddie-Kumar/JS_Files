import java.util.Scanner;
// Printing Pascal Triangle for number of rows as entered by user:
public class PascalTriangleUserInputRows {
    public static void main(String[] args) {
        int r = 0;
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter Number of Rows : ");
		r = scan.nextInt();
        for(int i=0; i<r; i++) { //Rows
            int n = 1;
            System.out.format("%"+(r-i)*2+"s",""); //whitespace padding.
            for(int j=0;j<=i;j++) {  //Columns
                 System.out.format("%4d",n);  //print number, width:4
                 n = n * (i - j) / (j + 1);
            }
            System.out.println(); //printing \n i.e. new-line.
        }
    }
}