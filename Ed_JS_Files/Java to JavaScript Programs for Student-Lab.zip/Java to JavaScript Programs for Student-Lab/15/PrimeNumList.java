public class PrimeNumList {
	public static void main(String[] args) {
		int num;
		boolean isDivisible = false;
		for (num = 2; num < 100; num++) {
			for (int i = 2; i <= num / 2; i++) {
				if (num % i == 0) { // nonprime number
					isDivisible = true;
					break;
				}
			}
			if (!isDivisible) System.out.printf("%d, ", num);
			isDivisible = false;
		}
	}
}