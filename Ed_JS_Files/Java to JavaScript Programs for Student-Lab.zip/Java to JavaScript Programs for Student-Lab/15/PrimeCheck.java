public class PrimeCheck {
    public static void main(String[] args) {
        int num = 27; //29;
        boolean isDivisible = false;
        for(int i = 2; i <= num/2; i++) {
            if(num % i == 0) {  //nonprime number
                isDivisible = true;
                break;
            }
        }
        if (!isDivisible) System.out.println(num + " is a prime number.");
        else System.out.println(num + " is NOT a prime number.");
    }
}