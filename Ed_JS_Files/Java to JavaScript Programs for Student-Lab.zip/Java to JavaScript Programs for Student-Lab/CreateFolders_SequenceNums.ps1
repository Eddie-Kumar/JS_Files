#gal -d mkdir
#01..26 | %{ {$_} -f "0#.##" }

$dirName = ''
1..26 | %{ 
    $dirName = $_.ToString("0#")
    New-Item -Path "." -Name $dirName  -ItemType "directory"
}

