package com.practical.demos;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class WriteFileOldWay{
 public static void main(String args[]) throws IOException {

  String fileName = "C:\\test\\Scores.csv";

  PrintWriter out = new PrintWriter(new FileWriter(fileName));
  out.println("Name,Score");
  out.println("John,8");
  out.println("Alex,7");
  out.println("Jen,9");
  out.close();
  System.out.println("File created - \"C:\\test\\Scores.csv\"");
 }
}