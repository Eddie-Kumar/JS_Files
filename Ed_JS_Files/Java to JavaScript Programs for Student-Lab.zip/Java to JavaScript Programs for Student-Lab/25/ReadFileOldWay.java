import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class ReadFileOldWay {
	public static void main(String[] args) {
		BufferedReader in = null;
		String file = "C:\\test\\test.txt";
		try {
			in = new BufferedReader(new FileReader(file));
			String str;
			while ((str = in.readLine()) != null) {
				System.out.println(str);
			}
		} catch (IOException e) {
			System.out.println(e.getClass().getSimpleName() + " exception thrown, msg: " + e.getMessage());
			e.printStackTrace();
		} finally {
			//in.close(); //Any object that implements java.lang.AutoCloseable gets auto-closed (at end of Try{} block),
							// however you can use try-with-resources to be safer side.
		}
	}
}
