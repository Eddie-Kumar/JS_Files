package com.practical.demos;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;

public class WriteFileNIO {
	public static void main(String[] args) throws IOException {
		Path filePath = FileSystems.getDefault().getPath("C:\\test", "test.txt"); //create path from source

		byte[] byteArray = Files.readAllBytes(filePath); // read whole file in one go (as byte array) - OK for small files

		Path fileCopy = FileSystems.getDefault().getPath("C:\\test", "test_copy.txt"); //create path for target
		Files.write(fileCopy, byteArray);  //write byte array
		System.out.println("File copied.");
	}
}
