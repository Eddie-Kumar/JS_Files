/*
Do Not Work:
	arr1 == arr2  is same as:  arr1.equals(arr2)  //Not OK.
Use:
	Arrays.equals(arr1, arr2)  //for 1 level deep.
	Arrays.deepEquals(arr1, arr2)  //for multi-level deep.

*/
import java.util.Arrays; 
class CompareArraysMultiLevels
{ 
    public static void main (String[] args)  
    { 
    	int[][] arr1 = {{1, 2}, {3, 4}};
    	int[][] arr2 = {{1, 2}, {3, 4}};
    	
        if (Arrays.equals(arr1, arr2)) System.out.println("Identical"); 
        	else System.out.println("Not identical");
        
        if (Arrays.deepEquals(arr1, arr2)) System.out.println("Identical"); 
        	else System.out.println("Not identical");

    } 
}
