/*
Do Not Work:
	arr1 == arr2  is same as:  arr1.equals(arr2)  //Not OK.
Use:
	Arrays.equals(arr1, arr2)  //for 1 level deep.
	Arrays.deepEquals(arr1, arr2)  //for multi-level deep.

*/
import java.util.Arrays; 
class CompareArrays
{
    public static void main (String[] args)  
    {
        int arr1[] = {1, 2, 3};
        int arr2[] = {1, 2, 3};
        
        //if (arr1.equals(arr2)) System.out.println("Identical"); 
        if (arr1 == arr2) System.out.println("Identical"); 
        	else System.out.println("Not identical"); 
        
        if (Arrays.equals(arr1, arr2)) System.out.println("Identical"); 
        	else System.out.println("Not identical"); 
    } 
}
