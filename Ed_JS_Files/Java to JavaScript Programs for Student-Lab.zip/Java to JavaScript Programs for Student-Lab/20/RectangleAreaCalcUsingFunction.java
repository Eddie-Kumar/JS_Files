import java.util.Scanner;

public class RectangleAreaCalcUsingFunction {
	private static Scanner sc;
	public static void main(String[] args) {
		double width, height;
		sc = new Scanner(System.in);
		System.out.println("Enter Width of Rectangle: ");
		width = sc.nextDouble();
		System.out.println("Enter the Height of Rectangle: ");
		height = sc.nextDouble();
		System.out.printf("%nThe Area of a Rectangle = %.2f%n", AreaofRectangle(width, height));
	}

	public static double AreaofRectangle(double width, double height) {
		return width * height;
	}
}