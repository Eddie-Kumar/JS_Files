public class ConditionsTest {
	static int i = 0;
	public static void main(String[] args) {
		int loop = 7;
		while (loop-->1) {
			int n = 0;
			int j = 7;
			System.out.println(getN(n, j));
			i++;
		}		
	}
	static int getN(int n, int j) {
		switch(i){
		case 0:
			if (j <= 4) {
			    n = 2;
			}
			break;

		case 1:
			if (3 < n || j > 4) {
			    n = 1;
			} else {
			    n = 2;
			}
			break;

		case 2:
			if (j > n && n!=0) {
			    n = 1;
			} else {
			    n = 2;
			}
			break;

		case 3:
			if (j > n) {
			    n = 1;
			    if (j > 4) {
			        n = 2;
			    } else {
			        n = 3;
			    }
			} else {
			    n = 4;
			    if (j%3 == 2) {
			        n = 5;
			    } else {
			        n = 6;
			    }
			}
			break;

		case 4:
			while (j > ++n || n <= 15) {
			    n+=n;
			}
			break;

		case 5:
			while (j-->0 && ++n<10) {
			    n*=2;
			}
			break;
		/*
		case 6:
			while (j-->0) {
			    ++n*=2;
			}
			break;
		 */
		default:
				System.out.println("i out of range");break;
		}
		return (n);
	}
}