public class NumericTest {

	public static void main(String[] args) {
		int i;
		int j = 6;
		int k = 10;
		
		System.out.println(1 + 2 * 3);
		System.out.println(1 + 2 - 3 * 4 / 5);
		System.out.println(3/2);
		System.out.println(3 / 2.0);
		System.out.println(3.0 / 2);
		System.out.println(1+2 * 3+4);
		System.out.println(5 % 3);
		System.out.println(6 % 3);
		System.out.println(2 % 3);
		System.out.println(0 % 3);
		System.out.println(20%3*2/2);
		System.out.println((((k))));
		System.out.println(k++);
		System.out.println(++k);
		//System.out.println(7++);  //Error: ++ operator can't be applied to a literal value.
		System.out.println(k++ + ++j);
		//System.out.println(k+++++j); //Error: missing space between concatenation of k++ and ++j.
		System.out.println(k += 1);
		System.out.println(k *= 2);
	}

}
