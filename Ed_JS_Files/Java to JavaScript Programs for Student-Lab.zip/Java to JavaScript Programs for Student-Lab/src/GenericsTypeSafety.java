import java.util.ArrayList;
import java.util.List;
public class GenericsTypeSafety {
	public static void main(String[] args) {
		{
			//int value = 5;
			List values = new ArrayList();
			values.add(7);
			values.add("test");
			int i = Integer.parseInt(values.get(1).toString());
			System. out.println(i);
		}
	}
}