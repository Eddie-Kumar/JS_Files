//package testPkg; 
class Container<T> {
	T value;
	public void show() {
		System.out.println(value.getClass().getName());
	}
	public T getValue() {
		return value;
	}
	public void setValue(T value) {
		this.value = value;
	}
}
public class GenericsDemo {
	public static void main(String[] args) {
		//int:
		Container<Integer> objI = new Container<>();
		objI.value = 9;
		objI.show();
		objI.setValue(55);
		System.out.println(objI.getValue());
		//float:
		Container<Float> objF = new Container<>();
		objF.value = 4.5f;
		objF.show();
		objF.setValue(8.8f);
		System.out.println(objF.getValue());
	}
}