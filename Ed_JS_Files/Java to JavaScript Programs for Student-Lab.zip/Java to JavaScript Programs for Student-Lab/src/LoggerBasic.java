import java.util.logging.*;
public class LoggerBasic {
	public static void main(String[] args) {
		try {
	        //Logger.getLogger("file.log").log(Level.SEVERE, null, ObjException);
			//Logger log = Logger.getLogger("c:\\test\\log.logger.txt");
			Log log = new Log("log.txt");
			log.logger.setLevel(Level.WARNING);
			log.logger.info("Info msg");
			log.logger.warning("warning msg");
			log.logger.severe("Severe msg");
		} catch (Exception e) {
		}
	}
}
