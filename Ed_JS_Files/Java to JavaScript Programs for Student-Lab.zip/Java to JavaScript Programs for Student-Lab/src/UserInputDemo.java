import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class UserInputDemo {
	public static void main(String[] args) {
		String name = "", ageStr = "";
		int age = 0;
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Enter your Name: ");
			name = reader.readLine();
			Scanner s = new Scanner(System.in); //Requires java.util.Scanner;
			System.out.println();
			System.out.print("Enter your Age: ");
			ageStr = s.nextLine();
			age = Integer.parseInt(ageStr);
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
		System.out.printf("Hi %s, so you are %d years old.", name, age);
	}
}
