import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
public class GetDatatypeOfUserInput {
	public static void main(String[] args) {
		String input = "";
	    try {
	        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	        System.out.print("Enter your content: ");
	        input = reader.readLine();
	        //System.out.println(input.getClass().getSimpleName()); //all STRING as input is always String.
	        boolean b1 = Pattern.matches("^\\d+$", input);
	        boolean b2 = Pattern.matches("^[0-9]{1,}", input);
	        boolean b3 = Pattern.matches("^([+-]?\\d*\\.+\\d*)$", input);
	        if(b1) {
	            System.out.println("It is an integer.");
	        } else if(b2) {
	            System.out.println("It is a String.");
	        } else if(b3) {
	            System.out.println("It is a Floating type value.");
	        }           
	    } catch (IOException ex) {
	        //Logger.getLogger(input.getClass().getSimpleName()).log(Level.SEVERE, null, ex);
	    }
	}
}
/*
myVar. getClass().getSimpleName());	//Integer
OR
myVar.getClass().getName() 		// java.lang.Integer
OR
myVar. getClass()); 			// class java.lang.Integer
OR in IF condition:
if (items.elementAt(1) instanceof Integer) {
   sum.add( i, items.elementAt(1));
}
*/