//see: https://illegalargumentexception.blogspot.com/2009/05/java-rough-guide-to-character-encoding.html
public class CharacterEncodeTest {

	public static void main(String[] args) {
		//Copyright symbol:
		System.out.println("\u00A9 Acme, Inc.");
		System.out.println("� Acme, Inc.");
	}
}
