public class DatabaseCheckJDBC {

	public static void main(String[] args) {
        try {
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); //for Microsoft SQL Server
            //Class.forName("com.mysql.cj.jdbc.Driver");   //for MySQL
            System.out.println("Driver Loaded successfully");
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver could NOT be loaded.");
            System.out.println(ex.getMessage());
        }
	}
}
