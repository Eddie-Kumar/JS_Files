// Package EmpPkg;

import java.util.Arrays;
import java.util.List;

class EmployeeCreateTest {
    public static void main(String[] args) throws Exception {
        // private static Employee[] arrEmps = {
        Employee[] arrEmps = {
                new Employee("Rex", 90000.0),
                new Employee("Bill", 200000.0),
                new Employee("Jeff", 150000.0, "USA"),
                new Employee("Mark", 220000.0)
            };
        List<Employee> listEmps = Arrays.asList(arrEmps);
        // listEmps.forEach((e) -> e.printEmployee()); //Single-statement Lambda-expr.
        // listEmps.forEach((e) -> { e.printEmployee(); System.out.println("------------\n");  });  //Multi-statement Lambda-expr.
        // for (Employee e : listEmps) { e.printEmployee(); System.out.println("------------\n"); }  //simple ForEach.
        //for (Employee e : listEmps) { System.out.println(e.toString()); }  //simple ForEach.
        // listEmps.forEach(Employee::printEmployee());  //won't work.
        // listEmps.stream().forEach(System.out::println);
        // listEmps.stream().filter(sal -> sal % 2 == 0).forEach(System.out::println);
        Employee emp = new Employee("Rex", 50000);
        emp.printEmployee();
        (new Employee("Rex", 50000)).printEmployee();
    }
}