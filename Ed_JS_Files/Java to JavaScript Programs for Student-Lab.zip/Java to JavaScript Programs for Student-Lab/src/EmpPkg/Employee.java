//Package EmpPkg;

import java.util.concurrent.atomic.AtomicInteger;

//import java.io.*;
public class Employee {
    private static final AtomicInteger count = new AtomicInteger(0); 
    private int id;
    private String name;
    private int age;
    private double salary;
    private String country;

    // This is the constructor of the class Employee
    public Employee(String name, double salary, String... country) throws Exception {
        // id = empid;
        id = count.incrementAndGet();
        this.name = name;
        this.salary = salary;
        if(country.length == 0)
            this.country = "UK";
        else if(country.length == 1)
            this.country = country[0];
        else
            throw new Exception("TooManyArguments"); // user provided too many arguments,
    }

    public void setAge(int empAge) {
        age = empAge;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public @Override
    String toString() {
        //super.toString();
        return "Employee-ID: \t" + id +", \tName: \t" + name + ", \tAge: \t" + age + ", \tSalary: \t" + salary + ", \tCountry: \t" + country;
    }


    /* Print the Employee details */
    public void printEmployee() {
        //System.out.printf("Employee-ID: \t%s, \tName: \t%s, \tAge: \t%d, \tSalary: \t%d, \tCountry: \t%s%n", id, name, age, salary, country);
        System.out.println("ID:" + id );
        System.out.println("Name:"+ name );
        System.out.println("Age:" + age );
        System.out.println("Salary:" + salary);
        System.out.println("Country:" + country );
    }
}