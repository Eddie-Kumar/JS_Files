import java.util.ArrayList;
public class GenericsDemo_NoTypeSafety {
	public static void main(String[] args) {
		int i;
		ArrayList list = new ArrayList();
		list.add(3);
		list.add("txt");
		i = Integer.parseInt(list.get(0).toString());
		System.out.println(i);
		i = Integer.parseInt(list.get(1).toString());
		System.out.println(i);
	}
}