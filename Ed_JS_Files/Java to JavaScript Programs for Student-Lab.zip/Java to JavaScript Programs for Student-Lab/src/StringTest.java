import javax.swing.JOptionPane;
public class StringTest {
	public static void main(String[] args) {
		String a = "helloworld";
		String t = "1.5";
		int i = 6;
		System.out.println(a);
		System.out.println(a.length());
		System.out.println(Double.parseDouble(t));
		System.out.println(i + a);
		System.out.println("x" + a + "x" + i);
		System.out.println(a.indexOf("l"));
		System.out.println(a.indexOf("X"));
		System.out.println(a.substring(0, 2));
		System.out.println(a.substring(a.indexOf("low"), a.length()));
		System.out.println(JOptionPane.showInputDialog(null, "Input something")); //Requires javax.swing package.
	}
}
