import java.util.Arrays;
import java.util.Collections;
import java.util.List;
public class ArrayTest {
	public static void main(String[] args) 	{
        int[] numbers = new int[] { 8, 7, -8, 5, 9, 10, -2, 4 };
        //String[] strings = new String[] { "learning", "java", "with", "baeldung" };
        /*Retreiving Array: (https://stackoverflow.com/questions/409784/whats-the-simplest-way-to-print-a-java-array)
        For one dimensional array:
            Arrays.toString() //OR Apache "Commons.Lang" library - ArrayUtils.toString()
            Arrays.asList()  //if Array contains Objects, use wrapper classes to store primitive types, e.g.: Integer[] a = new Integer[]{1,2,3};
        For multi dimensional array:
            Arrays.deepToString(arr)
        */
        //Sorting Array Elements: https://stackoverflow.com/questions/1694751/java-array-sort-descending
        System.out.println("Before Sort: " + Arrays.toString(numbers));
        Arrays.sort(numbers);
        System.out.println("After Sort: " + Arrays.toString(numbers));
        
        //see: https://www.baeldung.com/convert-array-to-list-and-list-to-array (expl: Guava Library)
        List<int[]> al = Arrays.asList(numbers);
        Collections.reverse(al);
        System.out.println("After Reverse: " + Arrays.toString(al.toArray()));
 
        Integer[] sourceArray = { 0, 1, 2, 3, 4, 5 };
        List<Integer> targetList = Arrays.asList(sourceArray);
        System.out.println("After Reverse: " + Arrays.toString(targetList.toArray()));
        Collections.reverse(targetList);
        
        Integer[] targetArray = targetList.toArray(new Integer[targetList.size()]);
        System.out.println("Afer Rev: " + Arrays.toString(targetArray));
        
        //Prior to Java 8
        System.out.println(Arrays.toString(numbers));
    
        // In Java 8 we have lambda expressions
        Arrays.stream(numbers).forEach(System.out::println);
        //} "Unresolved compilation problem": often just a block is not closed using curley-braces or an extra brace is there.
    }
}