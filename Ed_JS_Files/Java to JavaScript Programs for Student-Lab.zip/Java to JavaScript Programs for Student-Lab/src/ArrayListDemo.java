import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {
	public static void main(String[] args) {
		//Create & Initialise (one-liner): //List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6); //Immutable/fixed size.
		//Quickest Retrieval (one-liner): Arrays.toString(numbers.toArray());

		ArrayList<Integer> numbers  = new ArrayList<Integer>(); //mutable / dynamic flexible size.
		numbers.add(1); numbers.add(2); numbers.add(3); numbers.add(4); numbers.add(5); numbers.add(6);  

		//Retrieve (better control / multi-liner):
		//method 1: ForEach operator ':' :
		for (int number : numbers) {
		    System.out.print(number);
		}System.out.println();

		//method 2: Lambda Expression - with explicit Datatype (of parameter):
		numbers.forEach((Integer value) -> System.out.print(value));
		System.out.println();
		
		//method 2: Lambda Expression - Type inferred (no explicit Datatype for parameter):
		numbers.forEach(value -> System.out.print(value));
		System.out.println();
		
		//method 4: Method Referenced-Lambda Expression:
		numbers.forEach(System.out::print);
		System.out.println();

	//UPDATE TEST:
		numbers.set(2,30);
		
		//method 5: using Iterator:
		Iterator<Integer> iterator = numbers.iterator();
		while (iterator.hasNext()) {
		    System.out.print(iterator.next());
		}System.out.println();

		//REMOVE TEST:
		numbers.remove(2);

		//method 6: Arrays.toString() / deepToString():
		System.out.println(Arrays.deepToString(numbers.toArray()));
	}
}
