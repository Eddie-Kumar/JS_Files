public class ThreadDemo1 {
	public static void main(String[] args) throws InterruptedException {
	    Thread thread = new MyThread();
	    thread.start();
	    Thread.sleep(100);
	    //thread.stop();  deprecated: Threads rely on other treads' cooperative/Interruption, 
	    	//Thread can only be signalled by another thread to stop, you can't force thread to stop.
	    thread.interrupt(); //only sends signal, no guarantee of stop/termination.
	}

	private static class MyThread extends Thread {

	    @Override
	    public void run() {
	        int num = -1;

	        try {
	            Thread.sleep(600); //pausing the thread for 600 ms.
	            //if (num < 0) {throw new Exception();}
	            if (num > 0) {throw new Exception();} //no exception.
	            num = 100;
	            System.out.println("In try");
	        } 
	        catch (Exception e) {
	            System.out.println("In catch");
	        }
	        finally {
	            System.out.println("In finally");
	        }
	        System.out.println(num + " at the end.");
	    }
	}
}