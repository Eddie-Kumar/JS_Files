import java.util.Arrays;
import java.util.List;
public class PrintListUsingStream{
    public static void main(String[] args){
        // create a list
        List<String> mylist = Arrays.asList("hello","world");
        mylist.stream()
              .map(String::toUpperCase)
              .forEach(System.out::println);
    }
}
