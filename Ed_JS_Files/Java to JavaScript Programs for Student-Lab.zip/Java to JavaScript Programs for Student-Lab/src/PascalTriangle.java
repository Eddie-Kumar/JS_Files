// Printing Pascal Triangle for specified number of rows:
public class PascalTriangle {
    public static void main(String[] args) {
        int rows = 4;
        for(int i =0; i<rows; i++) {
            int n = 1;
            System.out.format("%"+(rows-i)*2+"s","");//whitespace padding.
            for(int j=0;j<=i;j++) {
                 System.out.format("%4d",n); //print number, width:4
                 n = n * (i - j) / (j + 1);
            }
            System.out.println(); //printing \n i.e. new-line.
        }
    }
}