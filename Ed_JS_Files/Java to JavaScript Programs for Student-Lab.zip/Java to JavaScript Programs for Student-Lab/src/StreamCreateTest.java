class SteamCreateTest {
    public static void main(String[] args) {
        String[] arr = new String[]{"a", "b", "c", "d"};
        Stream<String> streamArr = Arrays.stream(arr);
        Stream<String> streamArrPart = Arrays.stream(arr, 1, 3);  
    
    }
}