/* RUN IN CONSOLE USING -ea SWITCH:
Assertion is by default disabled, to enable use switch -ea Dog  OR -ea:Dog
or -enableassertions when running it (java -ea Dog) //don't use extension i.e. .class
*/
import java.util.Scanner;

public class AssertionDemo {
	public static void main(String args[]) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your age: ");
		int age = scanner.nextInt();
		assert age >= 18 : "Invalid age."; //same as: if(age<18) println("Invalid age.");
		System.out.printf("Your age %d is perfectly valid.", age); //this won't print if assert-condition fails
	}
}