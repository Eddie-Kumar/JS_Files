import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFromFileDemo1  {

	public static void main(String[] args) {
		String file = "C:\\test\\test.txt";
		BufferedReader in;
		try {
			in = new BufferedReader(new FileReader(file));
			String str;
			while ((str = in.readLine()) != null) {
		      System.out.println(str);
			}
		} catch (IOException e) {
		   System.out.println("Error occurred: " + e.getMessage() + e.gest);
		} finally {
		   //in.close();
		}
	}

}
