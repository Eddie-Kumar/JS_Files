//see: Java11: https://stackoverflow.com/a/29991733/5571827
//see: Java8: https://stackoverflow.com/a/28305759/5571827
public class EncryptDecript {

	public static void main(String[] args) {
		import org.apache.commons.codec.binary.Base64;

		// Encode data on your side using BASE64
		byte[] bytesEncoded = Base64.encodeBase64(str.getBytes());
		System.out.println("encoded value is " + new String(bytesEncoded));

		// Decode data on other side, by processing encoded data
		byte[] valueDecoded = Base64.decodeBase64(bytesEncoded);
		System.out.println("Decoded value is " + new String(valueDecoded));
		/*
		String seed = "ipNumber"; //password.
		String myIpValue = "192.168.0.1";
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(seed);
		String encrypted= encryptor.encrypt(myIpValue);
		 */
	}

}
