public class SplitStringToCountChar {
	public static void main(String[] args) {
		String s = "x.y.z";
		
		//Easiest:
		int count = s.length() - s.replace(".", "").length();
		System.out.println("Using replace() & subtraction: " + count);
		
		//Quickest:
		int replaceAll = s.replaceAll("[^.]", "").length();
		System.out.println("Using replaceAll(): " + replaceAll);

		//Using Arrays (but memory overhead):
		String[] parts = s.split("\\.");
		//System.out.println(Arrays.toString(parts));  //import java.util.Arrays;
		int occurances = parts.length - 1; //Count of Dots (.) in string.
		System.out.println("Using Arrays: " + occurances);
		
		//Java 8 -  Using chars().filter(): good for ASCII:
		long java8CharFilter = s.chars().filter(ch -> ch =='.').count();
		System.out.println("Using char().filter(): " + java8CharFilter);

		//Java 8 -  Using codePoints().filter(): better for unicodes:
		long java8CodePointsFilter = s.codePoints().filter(ch -> ch =='.').count();
		System.out.println("Using codePoints().filter(): " + java8CodePointsFilter); 
	}
}
