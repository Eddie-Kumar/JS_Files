public class MyClass {
    int x = 5;
  
    public static void main(String[] args) {
      MyClass myObj = new MyClass();
      System.out.println(myObj.x);
    }
  }