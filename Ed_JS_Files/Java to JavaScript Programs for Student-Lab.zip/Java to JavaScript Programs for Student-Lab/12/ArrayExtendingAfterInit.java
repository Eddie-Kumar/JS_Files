import java.util.Arrays;
/* As Arrays have fixed length, only option is to copy to an extendedArr array using arraycopy() method:
 * arraycopy(srcArr, srcArrStartPos, destArr, destArrStartPos, length);
*/
public class ArrayExtendingAfterInit {
	public static void main(String[] args) {
		String[] arr = new String[] { "A", "B", "C" };
		String[] extendedArr = new String[5];
		extendedArr[3] = "D";
		extendedArr[4] = "E";
		System.out.println("Extended array (Before): " + Arrays.deepToString(extendedArr));
		System.arraycopy(arr, 0, extendedArr, 0, arr.length);
		System.out.println("Original array: " + Arrays.deepToString(arr));
		System.out.println("Extended array: " + Arrays.deepToString(extendedArr));
	}
}
