public class ReverseStringRecursiveFunction {
	public static void main(String[] args) {
		String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String reversedString = reverse(s, s.length() - 1);
		System.out.println(reversedString);
	}
	static String reverse(String stringToReverse, int index) {
		if (index == 0) {
			return stringToReverse.charAt(0) + "";
		}
		char letter = stringToReverse.charAt(index);
		return letter + reverse(stringToReverse, index - 1);
	}
}
