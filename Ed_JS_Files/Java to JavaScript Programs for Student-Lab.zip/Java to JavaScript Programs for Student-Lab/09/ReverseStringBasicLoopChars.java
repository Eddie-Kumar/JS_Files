public class ReverseStringBasicLoopChars {
	public static void main(String[] args) {
		String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String reversedString = "";
        for(int i=s.length(); i>0; i--) {
            reversedString += s.charAt(i-1);
        }
        System.out.println(reversedString);
        String reversed = new StringBuilder(s).reverse().toString(); 
        System.out.println("reversed using reverse() function: " + reversed);
	}
}
