//  To search an element in ArrayList use contains() or indexOf()/lastIndexOf() methods.
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SearchInArrayList {
	public static void main(String[] args) {
		// ArrayList<String> arrList = new ArrayList<String>(Arrays.asList("1", "2", "3", "4", "5", "1", "2")); //asList() return List.
		// List<String> arrList1 = Arrays.asList("1", "2", "3", "4", "5", "1", "2"); //requires: import java.util.List;
		//Create ArrayList: 
		ArrayList<String> arrList = new ArrayList<String>();
		//Add elements: 
		arrList.add("1"); arrList.add("2"); arrList.add("3");

		String strToFind = "1";
		int index;
		
		//Use contains() to get boolean (true/false):
		//Sytax: boolean contains(elementToFind):
		boolean found = arrList.contains(strToFind);
		System.out.printf("arrList contains %s: %b %n", strToFind, found);

		//Use indexOf() to get index (if found):
		//Sytax: int indexOf(Object element) //Note: returns -1 if not found:
		index = arrList.indexOf(strToFind);
		if (index >= 0) System.out.printf("Found %s at index: %d: %n", strToFind, index);
		else System.out.printf("%s not found %n", strToFind);

		//Use lastIndexOf() to get index of the last occurrence of element (where multiple instances of element exist):
		//Sytax: int lastIndexOf(Object element) //Note: returns -1 if not found:
		index = arrList.lastIndexOf(strToFind);
		if (index >= 0) System.out.printf("Last occurrence of %s found at index: %d: %n", strToFind, index);
		else System.out.printf("%s not found %n", strToFind);
	}
}