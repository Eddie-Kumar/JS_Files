//Run this code ONLY IN CONSOLE / CMD PROMPT (NOT IN IDE):
import java.time.*;
import javax.swing.JOptionPane;
/*
import java.util.Date;
import java.util.Calendar;
import java.time.Period;
import java.time.temporal.ChronoUnit;
*/
class AgeCalcUserInputGUI{
    public static void main(String args[]) {
	String dobString = (JOptionPane.showInputDialog(null, "Enter DOB (YYYY-MM-DD):")); //Requires javax.swing package.
        LocalDate birthday = LocalDate.parse(dobString);
        LocalDate today = LocalDate.now();                          //Today's date
        Period p = Period.between(birthday, today); //EdReminder: Same as TimeSpan PowerShell & .NET object.
        System.out.println("You are " + p.getYears() + " years, " + p.getMonths() + " months and " + p.getDays() + " days old/young." );
    }
}