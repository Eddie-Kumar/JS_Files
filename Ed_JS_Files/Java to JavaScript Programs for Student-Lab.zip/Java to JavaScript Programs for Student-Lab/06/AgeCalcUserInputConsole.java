//Run this code ONLY IN CONSOLE / CMD PROMPT (NOT IN IDE):
import java.time.*;
/*
import java.util.Date;
import java.util.Calendar;
import java.time.Period;
import java.time.temporal.ChronoUnit;
*/
class AgeCalcUserInputConsole{
    public static void main(String args[]) {
        System.out.println("Enter DOB (YYYY-MM-DD): ");
        String dobString = System.console().readLine();
        LocalDate birthday = LocalDate.parse(dobString);
        LocalDate today = LocalDate.now();                          //Today's date
        // LocalDate birthday = LocalDate.of(1960, Month.JANUARY, 1);  //Birth date
        // LocalDate birthday = LocalDate.of(1970, Month.AUGUST, 2);  //Birth date

        Period p = Period.between(birthday, today); //EdReminder: Same as TimeSpan PowerShell & .NET object.
        System.out.println("You are " + p.getYears() + " years, " + p.getMonths() + " months and " + p.getDays() + " days old/young." );
    }
}