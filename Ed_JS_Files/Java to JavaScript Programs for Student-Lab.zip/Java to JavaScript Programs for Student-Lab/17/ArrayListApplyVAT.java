import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class ArrayListApplyVAT {
	public static void main(String[] args) {
		//ArrayList<Double> products = new ArrayList<>(Arrays.asList(90.0d,100d,80d,120d)); 
		//List<Float> products = Arrays.asList(90,100,80,120);  //asList() return List.
		//ArrayList<String> products = new ArrayList<String>();
		//Add elements: products.add(90); products.add(100); products.add(80); products.add(120);

		ArrayList<Float> products = new ArrayList<>(Arrays.asList(90.0f,100f,80f,120.5f)); //Immutable fixed size.

		System.out.println("Before VAT: " + Arrays.toString(products.toArray()));
		for(int i = 0; i < products.size(); i++) {
		    products.set(i, products.get(i)*1.12f);
		}//for (Float product : products) {} //Can't use "ForEach, Lamda-expr nor Iterator" as no index number.
		System.out.println("After VAT: " + Arrays.toString(products.toArray()));
	}
}