//string to char[] array:
import java.util.Arrays;

public class StringToChar {
	public static void main(String[] args) {
		String str;

		str = "helloworld"; //length: 10
		//METHOD-1: using str.toCharArray() method:
		char[] chars = str.toCharArray();
		System.out.println(Arrays.toString(chars) + " length: " + chars.length);

		str = "superhero"; //length: 9
		//METHOD-2: string to char[] array - using str.toCharArray() method:
		char[] chars2 = new char[10];
		for (int i = 0; i<str.length(); i++) {
			chars2[i] = str.charAt(i);  //str.charAt(<index>) retuns char at specific index
		}
		System.out.println(Arrays.toString(chars2) + " length: " + chars2.length);

		str = "masterclass"; //length: 11
		//METHOD-3: Copy each character of string into char array
		char[] chars3 = new char[10];
		str.getChars(0, 10, chars3, 0);  //(str_begin_index, str_end_index, char_arr, char_begin_index)
		System.out.println(Arrays.toString(chars3) + " length: " + chars3.length);
	}
}