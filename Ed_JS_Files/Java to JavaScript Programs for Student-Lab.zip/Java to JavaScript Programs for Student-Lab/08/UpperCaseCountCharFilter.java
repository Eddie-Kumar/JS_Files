public class UpperCaseCountCharFilter {
	public static void main(String[] args) {
		String str = "HelloWorld.";
		System.out.println(str.chars().filter((s)->Character.isUpperCase(s)).count());
	}
}
