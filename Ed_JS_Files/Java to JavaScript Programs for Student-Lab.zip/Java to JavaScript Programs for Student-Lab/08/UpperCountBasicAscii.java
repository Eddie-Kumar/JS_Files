public class UpperCountBasicAscii
{
    public static void main(String[] args)
    {
        String str = "this is TEST";
        char ch;
        int uppercase=0,lowercase=0;
        for(int i=0;i<str.length();i++)
        {
            ch = str.charAt(i);
            int asciivalue = (int)ch;
            if(asciivalue >=65 && asciivalue <=90){
                uppercase++;
            }
            else if(asciivalue >=97 && asciivalue <=122){
                lowercase++;
            }
        }
        System.out.printf("Lowercase chars: %d \nUppercase chars: %d", lowercase, uppercase);
    }
}