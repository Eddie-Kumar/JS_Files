public class UpperCaseCharsCount {
	public static void main(String[] args) {
		String s = "Fabulous speech by MP on Veganism in Australian parliament.";
		int upper=0, lower=0;
		//"xyz".chars().forEach(c -> System.out.print((char)c));
		for (int k = 0; k < s.length(); k++) {
		    // Count uppercase chars:
		    if (Character.isUpperCase(s.charAt(k))) upper++;
		    // Count lowercase chars:
		    if (Character.isLowerCase(s.charAt(k))) lower++;
		}
		System.out.printf("There are %d uppercase a %d lowercase characters.",upper,lower);
	}
}
