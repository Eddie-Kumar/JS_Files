public class StringSearchCompareDemo {
	public static void main(String[] args) {
		String s1 = "Foo Bar Hello World.";
		String s2 = "Bar";
		boolean b;
		
		//contains(): Safe case-insensitive s1 compare - returns Boolean:
		b = s1.toLowerCase().contains(s2.toLowerCase());
		System.out.println(b);
		
		//startsWith(): at beginning:
		b = s1.startsWith("Foo");  			// true
		System.out.println(b);

		//endsWith(): at the end:
		b = s1.endsWith("World.");          // true
		System.out.println(b);

		//indexOf(): Anywhere - returns int index:
		b = s1.indexOf(s2) >= 0;        	// true
		System.out.println(b);

		//Regular expressions: powerful flexible: (ignore case/multi-match etc.):
		b = s1.matches(".*Bar.*");    		// true
		System.out.println(b);
		
		s2 = s1.substring(1, 3);  //.substring(index, position)
		System.out.println("\"" + s2 + "\" - length: " + s2.length());
	}
}
