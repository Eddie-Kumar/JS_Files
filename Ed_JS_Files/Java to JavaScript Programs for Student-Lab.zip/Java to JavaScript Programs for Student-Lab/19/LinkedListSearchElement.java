import java.util.LinkedList;

public class LinkedListSearchElement {
    public static void main(String[] args) {
        LinkedList<String> empList = new LinkedList<>();

        empList.add("Chris");
        empList.add("David");
        empList.add("John");
        empList.add("Jenny");
        empList.add("John");

        String findVal = "John";

        // Check if LinkedList contains particular element:
        System.out.println("Does LinkedList contain : '" + findVal + "' : " + empList.contains(findVal));
        //System.out.printf("Does LinkedList contain : '%s'", findVal + " : " + empList.contains(findVal));

        // Find index of element in LinkedList (start finding from front):
        System.out.println("indexOf '" + findVal + "' : " + empList.indexOf(findVal));

        // Find index of element in LinkedList (start finding from rear):
        System.out.println("Last indexOf '" + findVal + "' : " + empList.lastIndexOf(findVal));
    }
}