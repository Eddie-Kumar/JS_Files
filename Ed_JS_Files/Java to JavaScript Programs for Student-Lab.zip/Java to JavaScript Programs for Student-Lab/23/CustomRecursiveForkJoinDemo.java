﻿class CustomRecursiveForkJoinDemo {
    public static void main (String[] args)  {

        ForkJoinPool forkJoinPool = ForkJoinPool.commonPool();
        // public static ForkJoinPool forkJoinPool = new ForkJoinPool(2);

        //using execute():
        forkJoinPool.execute(customRecursiveTask);
        int result = customRecursiveTask.join();

        //int result = forkJoinPool.invoke(customRecursiveTask);

        //using separate fork() and join(). fork() submits a task to the` pool, but it doesn’t trigger its execution.
        //in RecursiveAction join() returns null; RecursiveTask<V> returns result of task’s execution:
        // customRecursiveTaskFirst.fork();
        // result = customRecursiveTaskLast.join();
    } 
}


