import java.util.stream.Stream;
class StreamTest{
    public static void main(String[] args)
    {
        Stream<String> stream = Stream.of("Greeks", "Future", "Great answer", "Filters");
        stream.filter(str -> str.endsWith("s")).forEach(System.out::println);   // OK
        //stream.filter(str -> str.startsWith("F")).forEach(System.out::println);   // //ERROR: Stream is closed.
    }
}
