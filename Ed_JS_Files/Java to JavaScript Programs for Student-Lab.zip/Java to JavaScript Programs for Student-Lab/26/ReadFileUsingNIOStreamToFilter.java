import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
public class ReadFileUsingNIOStreamToFilter {
	public static void main(String[] args) {
		Path path = Paths.get("C:\\test\\test.txt");
		try{
			//Method-1:
			// List<String> lines = Files.readAllLines(path);// reads in memory, hence may return "OutOfMemoryError" if too large file, don't forget Generic-Type-Parameter <String>
			// for(Object line:lines) { System.out.println(line); }
			
			//Method-2:
			Files.lines(path).forEach(System.out::println);//Safer: no worries about OutOfMemoryError, as reads line-by-line
			
			//Method-3:
			// Files.lines(path).filter(line -> line.startsWith("test")).forEach(System.out::println); //filters each line before sending/passing on

			//Method-4:
			//for(String line:Files.lines(path).toArray(String[]::new)) { System.out.println(line); }//Stream to Array<String> using "Method Reference"
			
			//Method-5:
			//for(String line:Files.lines(path).toArray(size -> new String[size])) { System.out.println(line); }//Stream to Array<String> using manual array creation.

			//Method-6:
			//for(Object line:Files.lines(path).toArray()) { System.out.println(line); }//Stream to Array<Object> as toArray() (without parameter) by default returns Object-Array.
		} catch (IOException e) {
			System.out.println(e.getClass().getSimpleName() + " exception thrown, msg: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
