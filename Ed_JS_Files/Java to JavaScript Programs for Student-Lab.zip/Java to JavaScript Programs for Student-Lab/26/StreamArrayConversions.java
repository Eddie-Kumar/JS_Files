import java.util.Arrays;
import java.util.stream.Stream;

class StreamArrayConversions {
    public static void main(String[] args) {
        String[] arr = new String[]{"a", "b", "c", "d"};
        Stream<String> streamArr = Arrays.stream(arr);          //Array to Stream
        Stream<String> streamArrPart = Arrays.stream(arr, 1, 3);//Array to Stream from selected elements
        streamArr.forEach(System.out::println);
        
//        String[] stringArray = streamArrPart.toArray(String[]::new);  //Stream to Array
        String[] stringArray = streamArrPart.toArray(size -> new String[size]);
        System.out.println(Arrays.toString(stringArray));
    }
}