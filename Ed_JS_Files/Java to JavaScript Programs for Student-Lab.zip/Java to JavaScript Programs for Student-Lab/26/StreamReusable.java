import java.util.function.Supplier;
import java.util.stream.Stream;
class StreamReusable{
    public static void main(String[] args)
    {
        Supplier <Stream<String>> streamSupplier = () -> Stream.of("Greeks", "Future", "Great answer", "Filters");
        //Supplier <Stream<String>> streamSupplier = () -> Stream.of("Greeks", "Future", "Great answer", "Filters").filter(s -> s.startsWith("a"));
        System.out.println("\nStartsWith('F'):");
        streamSupplier.get().filter(str -> str.startsWith("F")).forEach(System.out::println);
        System.out.println("\nEndsWith('s')");
        streamSupplier.get().filter(str -> str.endsWith("s")).forEach(System.out::println);
    }
}
/* Reusing Steam:
    Supplier<Stream<String>> streamSupplier =  () -> Stream.of("a1", "a2", "b1", "b3", "c", "d2").filter(s -> s.startsWith("a"));
    streamSupplier.get().anyMatch(s -> true);
    streamSupplier.get().noneMatch(s -> true);
*/