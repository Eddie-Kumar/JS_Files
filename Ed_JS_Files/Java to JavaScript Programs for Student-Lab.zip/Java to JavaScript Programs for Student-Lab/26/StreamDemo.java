import java.util.stream.Stream;
class StreamDemo{
    public static void main(String[] args)
    {
        Stream<String> stream = Stream.of("Greeks", "Future", "Great answer", "Filters");
        // stream.filter(str -> str.endsWith("s")).forEach(System.out::println);   // OK
        stream.filter(str -> str.startsWith("F")).forEach(System.out::println);   // //ERROR: Stream is closed.
    }
}

/* Reusing Steam:
Supplier<Stream<String>> streamSupplier =  () -> Stream.of("a1", "a2", "b1", "b3", "c", "d2").filter(s -> s.startsWith("a"));
streamSupplier.get().anyMatch(s -> true);   // ok
streamSupplier.get().noneMatch(s -> true);  // ok
*/