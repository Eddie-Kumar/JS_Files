import java.util.Arrays;
public class SecondLargest_Short {
	public static void main(String[] args) {
		int arr[] = { 83, 34, 13, 64, 72, 90, 10, 15, 8, 21 }; //new int[]  {}
		int tmp[] = arr;
		System.out.println("Out of following array elements:" );
		for (int n : arr) {
			System.out.print(n + "\t");
		}
		Arrays.sort(tmp);  //For descending order simply iterate in reverse order, for array of objects: Arrays.sort(objArray, Collections.reverseOrder()); 
		System.out.println("\n\nSecond largest number would be: " + tmp[tmp.length-2]);
 	}
}

/*OUTPUT:
Out of following array elements:
83	34	13	64	72	90	10	15	8	21	

Second largest number would be: 83
*/