public class SecondLargest {
	public static void main(String[] args) {
		int arr[] = { 83, 34, 13, 64, 72, 90, 10, 15, 8, 21 }; //new int[]  {}
		int largest = arr[0];
		int secondLargest = arr[0];
		System.out.println("Out of following array elements:" );
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+"\t");
		}
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] > largest) {
				secondLargest = largest;
				largest = arr[i];
			} else if (arr[i] > secondLargest) {
				secondLargest = arr[i]; 
			}
		}
 		System.out.println("\n\nThe second largest number is: " + secondLargest);
 	}
}

/* OUTPUT:
Out of following array elements:
83	34	13	64	72	90	10	15	8	21	

The second largest number is: 83
*/