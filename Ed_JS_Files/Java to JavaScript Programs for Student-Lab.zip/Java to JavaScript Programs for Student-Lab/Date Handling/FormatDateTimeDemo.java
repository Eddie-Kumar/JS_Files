/*Use the DateTimeFormatter class that provides: ofPattern() to set a format, which is used by the LocalDateTime class's format() method to format and also parse() method for parsing string into a date-time objects.*/

import java.time.LocalDateTime; // Import the LocalDateTime class
import java.time.format.DateTimeFormatter; // Import the DateTimeFormatter class

public class FormatDateTimeDemo {
  public static void main(String[] args) {
    LocalDateTime now = LocalDateTime.now();
    System.out.println("Before formatting: " + now);
    DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    String formattedDate = now.format(fmt);
    System.out.println("After formatting: " + formattedDate);
  }
}
