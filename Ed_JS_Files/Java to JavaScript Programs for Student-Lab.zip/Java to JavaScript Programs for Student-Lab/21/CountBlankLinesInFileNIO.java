import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
public class CountBlankLinesInFileNIO {
	public static void main(String[] args) {
		Path path = Paths.get("C:\\test\\test.txt");
		try{
			long lineCount = Files.lines(path).count();
			System.out.println(lineCount);

			//List<String> lines = Files.readAllLines(path);//beware: you may get an OutOfMemoryError if too large line, don't forget Generic-Type-Parameter <String>
			//Read file:
			//System.out.println(Arrays.toString(lines.toArray()));
			//for(String line:lines){
			//	System.out.println(line);// print each line
			//}
		} catch (IOException e) {
			System.out.println(e.getClass().getSimpleName() + " exception thrown, msg: " + e.getMessage());
			e.printStackTrace();
		} finally {
			//in.close(); //Any object that implements java.lang.AutoCloseable gets auto-closed (at end of Try{} block),
							// however you can use try-with-resources to be safer side.
		}
	}
}
