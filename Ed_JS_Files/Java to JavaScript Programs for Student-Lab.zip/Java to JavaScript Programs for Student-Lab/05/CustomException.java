@SuppressWarnings("serial")
class MyException extends Exception
{
      //private static final long serialVersionUID = 1L;  //OR @SuppressWarnings("serial") annotation.
      // Parameterless Default Constructor:
      public MyException() { 
            System.out.println("Blank space. \nMsg: " + this.getMessage() + "\n" + this.getClass());
      }
      // Explicit Constructor that accepts a message:
      public MyException(String message) {
            super(message);
            System.out.println("Hash. \nMsg: " + this.getMessage() + "\n" + this.getClass());
      }
}
class CustomException {
      public static void main(String args[]) {
            //String s = "space-hash";
            // String s = " space-hash";
            String s = "#space-hash";
            //String s = "# space-hash"; //first is # then space.
            try {
                  if(s.contains(" ")) {
                        throw new MyException();
                  } else if(s.contains("#")) {
                        throw new MyException("#Hash# found!");
                  } else {
                        System.out.println("no space found in: " + s);
                  }
            } catch(MyException ex) {
                        //Processing of message
            }
      }
}