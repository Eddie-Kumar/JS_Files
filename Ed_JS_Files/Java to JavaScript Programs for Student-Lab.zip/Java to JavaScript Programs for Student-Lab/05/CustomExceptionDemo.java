/*
import java.io.File;
import java.util.Scanner;

//https://www.baeldung.com/java-new-custom-exception

public class IncorrectFileExtensionException extends RuntimeException {
    public IncorrectFileExtensionException(String errorMessage, Throwable err) {
        super(errorMessage, err);
    }
}
    
class CustomExceptionDemo {
    public static void main(String[] args) {
        String fileName;
        try (Scanner file = new Scanner(new File(fileName))) {
            if (file.hasNextLine()) {
                return file.nextLine();
            } else {
                throw new IllegalArgumentException("Non readable file");
            }
        } catch (FileNotFoundException err) {
            if (!isCorrectFileName(fileName)) {
                throw new IncorrectFileNameException(
                "Incorrect filename : " + fileName , err);
            }
        } catch(IllegalArgumentException err) {
            if(!containsExtension(fileName)) {
                throw new IncorrectFileExtensionException(
                "Filename does not contain extension : " + fileName, err);
            }
        }
    }
}

*/