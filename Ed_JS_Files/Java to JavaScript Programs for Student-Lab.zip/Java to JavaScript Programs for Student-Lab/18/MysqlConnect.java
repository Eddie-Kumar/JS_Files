import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class MysqlConnect {

	public static void main(String[] args) {
		MysqlConnection mc = new MysqlConnection();
		
		try {
		    Statement stmt = mc.connect().createStatement();
			String sql = "select * from customer";
		    ResultSet rs = stmt.executeQuery(sql);
		    
		    int id;
		    String name, address, city, country;
		    System.out.printf("%s \t %-15s %-30s %-15s %s %n", "ID", "Name", "Address", "City", "Country");
		    while (rs.next()) {
		        id = rs.getInt("cid");
		        name = rs.getString("name");
		        address = rs.getString("address");
		        city = rs.getString("city");
		        country = rs.getString("country");
			    System.out.printf("%s \t %-15s %-30s %-15s %s %n", id, name, address, city, country);
		        //float f = rs.getFloat("address");
		    }

		} catch (SQLException e) {
		    e.printStackTrace();
		} finally {
		    mc.disconnect();
		}
	}
}

class MysqlConnection {
    //DB constants:
    private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    private static final String MAX_POOL = "250";

    private Connection conn;
    private Properties p;  //properties object for getProperties() method

    //Method for returning properties:
    private Properties getProperties() {
        if (p == null) {
            p = new Properties();
            p.setProperty("user", USERNAME);
            p.setProperty("password", PASSWORD);
            p.setProperty("MaxPooledStatements", MAX_POOL);
        }
        return p;
    }

    //Connect to DB:
    public Connection connect() {
        if (conn == null) {
            try {
                Class.forName(DATABASE_DRIVER);
                conn = DriverManager.getConnection(DATABASE_URL, getProperties());
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    //Disconnect from DB:
    public void disconnect() {
        if (conn != null) {
            try {
                conn.close();
                conn = null;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}