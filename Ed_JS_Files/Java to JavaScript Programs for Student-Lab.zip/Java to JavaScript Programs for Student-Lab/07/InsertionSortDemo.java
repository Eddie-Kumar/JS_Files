//Compare-Right: pick a position (NOT value) then compare its value to all others, if (previous > next value) then swap their positions, otherwise check next:
import java.util.Arrays;
class InsertSortDemo {
    public static void main(String args[]) 
    { 
        int arr[] = { 12, 11, 13, 5, 6 };
        System.out.println("Before sort: " + Arrays.toString(arr));
        // InsertionSort1(arr);
        InsertionSort2(arr);
        System.out.println("\nAfter sort: " + Arrays.toString(arr));
    }
    //Method-1:
    //Compare-Right: pick a position then compare it to values on the right, if (position > right value) then swap their positions, otherwise check next:
    static void InsertionSort1(int arr[]) {
        int tmp;
		for (int i=0, j=1; j < arr.length; ++i, j=i+1) {
            for(;j < arr.length; ++j) {
                if (arr[i] > arr[j]) {
                    tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                }
            }
            System.out.println("Whilst sorting: " + i + " : " + Arrays.toString(arr));
        }
    }
    //Method-2:
    //Compare-Left: pick a position (key) then compare it to values on the left, if (left value > key) then swap their positions, otherwise check next:
    static void InsertionSort2(int arr[]) {
            for (int i = 1; i < arr.length; ++i) {
                int key = arr[i];
                int j = i - 1;
                while (j >= 0 && arr[j] > key) {
                    arr[j + 1] = arr[j];
                    j = j - 1;
                }
                arr[j + 1] = key;
                System.out.println("Whilst sorting: " + i + " : " + Arrays.toString(arr));
            } 
        } 
}