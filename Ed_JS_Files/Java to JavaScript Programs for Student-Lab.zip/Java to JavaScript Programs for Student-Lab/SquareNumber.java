

class SquareNumber{
    SquareNumber() {
        System.out.println("constructor");
    }
  
    int x = 5;
  
    public static void main(String[] args) {
      SquareNumber myObj = new SquareNumber();
      System.out.println(Sqr(myObj.x));
    }
    static int Sqr(int i){
      return i*i;
    }
  }