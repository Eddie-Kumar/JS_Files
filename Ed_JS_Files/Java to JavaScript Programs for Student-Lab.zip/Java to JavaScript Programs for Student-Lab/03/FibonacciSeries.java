public class FibonacciSeries {
    static int iteration = 10, num1 = 0, num2 = 1;
    public static void main(String[] args) {
        System.out.print("First " + iteration + " numbers of Fibonacci Series (sums of the two preceding numbers):\n");

        //Method-1: using simple For/While loop:
        for (int i=1; i <= iteration; ++i) {
            System.out.print(num1 + ", ");
            int sum = num1 + num2;
            num1 = num2;
            num2 = sum;
        }

        //Method-2: using :
        System.out.print("\n\n0, 1, ");  //printing first 2 numbers of series in advance:
        num1 = 0; num2 = 1;
        printFibonacciSeries(iteration);
    }

    static void printFibonacciSeries(int iteration) {
        if(iteration > 2) {
            int sum = num1 + num2;
            System.out.print(sum + ", ");
            num1 = num2;
            num2 = sum;
            printFibonacciSeries(--iteration);
        }
    }
}